import React from "react";
import "./App.css";
import JokeApp from "./components/JokeApp";

function App() {
  //console.log(this.state.todos);
  return (
    <div className="App">
      <JokeApp />
    </div>
  );
}

export default App;
