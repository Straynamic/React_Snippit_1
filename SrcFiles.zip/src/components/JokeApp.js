import React from "react";
import Joke from "./Joke";

function JokeApp() {
  return (
    <div>
      <Joke
        question="I waited and stayed up all night and tried to figure out where the sun was."
        punchline="Then it dawned on me."
      />
      <Joke
        question=" I told my friend 10 jokes to get him to laugh."
        punchline="Sadly, no pun in 10 did."
      />
      <Joke
        question="How does NASA organize a party?"
        punchline="They planet."
      />
      <Joke
        question="What’s a pirates favorite letter?"
        punchline="You think it’s R but it be the C."
      />
      <Joke
        question="You know why you never see elephants hiding up in trees?"
        punchline="Because they’re really good at it."
      />
    </div>
  );
}

export default JokeApp;
